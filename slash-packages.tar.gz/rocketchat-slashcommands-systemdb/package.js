Package.describe({
        name: 'rocketchat:slashcommands-systemdb',
        version: '0.0.1',
        summary: 'Exec systemDB queries',
        git: ''
});

Package.onUse(function(api) {
        api.use([
        'underscore',
        'ecmascript',
        'rocketchat:lib'
        ]);

        api.addFiles('client.js', 'client');
        api.addFiles(['server.js',
                     'methods/systemDBMessages.js'], 'server');
});
