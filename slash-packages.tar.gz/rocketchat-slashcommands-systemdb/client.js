RocketChat.slashCommands.add('systemdb', undefined, {
  description: 'System DB to get patched and unpatched servers',
  params: 'patched/unpatched'
});
