function SystemDB(command, params, item) {
   if (command !== 'systemdb' || !Match.test(params, String)) {
      return;
   }

   console.log("Command "+ command);
   console.log("function "+ params);

   var curlrun = "";
   var prefix= "";
   var region=""

   var paramsArray = params.split(" ");

   if (paramsArray[0] === "patched") {
      if (paramsArray.length < 2 ) {
         curlrun = "/home/ahonore/scripts/systemdb-patched.sh"   
         prefix=" servers are patched*"
      }
      else {
         curlrun = "/home/ahonore/scripts/systemdb-patched-region.sh "+paramsArray[1]   
         prefix=" servers are patched in region "+paramsArray[1]+"*"
      }
   }
   else {
      if (paramsArray.length < 2 ) {
         curlrun = "/home/ahonore/scripts/systemdb-unpatched.sh"
         prefix=" servers are unpatched*"
      }
      else {
         curlrun = "/home/ahonore/scripts/systemdb-unpatched-region.sh "+paramsArray[1]   
         prefix=" servers are unpatched in region "+paramsArray[1]+"*"
      }
   }

   console.log("prefix "+ prefix);
   console.log("curlrun "+ curlrun);

   const user = RocketChat.models.Users.findOneById('rocket.cat', { fields: { username: 1 } });


   var exec = require('child_process').exec;
   var message = "";
 
     return exec("sh "+curlrun ,function (error, stdout, stderr) {

      message = stdout;
      var messageJson = JSON.parse(message);
      message = "*"+messageJson.result + prefix;

      console.log(message);
      
      if (error !== null) {
         console.log('exec error: ' + error);
      }

      var msgObject = {
         _id: Random.id(),
         rid: item.rid,
         ts: new Date,
         u: user,
         msg: message
      };

      //Insert message into the Database for persistance
      var Fiber = require('fibers');
      Fiber(function() {
         RocketChat.models.Messages.insert(msgObject);
      }).run();

      msgStream.emit(item.rid, msgObject );

   });

}

RocketChat.slashCommands.add('systemdb', SystemDB);

