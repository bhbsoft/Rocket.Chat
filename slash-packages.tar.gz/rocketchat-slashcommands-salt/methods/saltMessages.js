import moment from 'moment';

Meteor.methods({
	'saltMessage'(data) {
//		if (!Meteor.userId()) {
//			throw new Meteor.Error('error-invalid-user', 'Invalid user', {
//				method: 'mailMessages'
//			});
//		}
		check(data, Match.ObjectIncluding({
			rid: String,
		}));
                
                RocketChat.models.Messages.insert(message);
       	}
});
