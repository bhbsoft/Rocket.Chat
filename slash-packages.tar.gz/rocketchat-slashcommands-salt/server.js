function Salt(command, params, item) {
   if (command !== 'salt' || !Match.test(params, String)) {
      return;
   }

   console.log("Command "+ command);
   console.log("params "+ params);

   const user = RocketChat.models.Users.findOneById('rocket.cat', { fields: { username: 1 } });


   var exec = require('child_process').exec;
   var message = "";
 
//   return exec("ssh root@165.227.120.175 \"salt '*' state.show_highstate\"", function (error, stdout, stderr) {
     return exec("cat /home/ahonore/salt.txt",function (error, stdout, stderr) {

      message = stdout;
      if (error !== null) {
         console.log('exec error: ' + error);
      }

      var msgObject = {
         _id: Random.id(),
         rid: item.rid,
         ts: new Date,
         u: user,
         msg: message
      };

      //Insert message into the Database for persistance
      var Fiber = require('fibers');
      Fiber(function() {
         RocketChat.models.Messages.insert(msgObject);
      }).run();

      msgStream.emit(item.rid, msgObject );

   });

}

RocketChat.slashCommands.add('salt', Salt);

