Package.describe({
        name: 'rocketchat:slashcommands-salt',
        version: '0.0.1',
        summary: 'Exect salt commands',
        git: ''
});

Package.onUse(function(api) {
        api.use([
        'underscore',
        'ecmascript',
        'rocketchat:lib'
        ]);

        api.addFiles('client.js', 'client');
        api.addFiles(['server.js',
                     'methods/saltMessages.js'], 'server');
});
