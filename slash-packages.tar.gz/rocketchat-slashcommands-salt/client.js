RocketChat.slashCommands.add('salt', undefined, {
  description: 'Remote Salt command in Chat',
  params: '<message>'
});
